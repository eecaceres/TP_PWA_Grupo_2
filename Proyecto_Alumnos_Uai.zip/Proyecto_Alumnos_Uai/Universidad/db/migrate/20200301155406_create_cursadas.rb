class CreateCursadas < ActiveRecord::Migration
  def change
    create_table :cursadas do |t|
      t.string :Nom_Materia
      t.string :Carrera
      t.integer :Cant_Alumnos
      t.string :Turno
      t.time :Horario
      t.string :Comision

      t.timestamps null: false
    end
  end
end
