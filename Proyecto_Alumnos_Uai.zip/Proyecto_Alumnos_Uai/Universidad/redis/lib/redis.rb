require "redis/version"

module Redis
  # Your code goes here...
end
