require 'test_helper'

class CursadaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
