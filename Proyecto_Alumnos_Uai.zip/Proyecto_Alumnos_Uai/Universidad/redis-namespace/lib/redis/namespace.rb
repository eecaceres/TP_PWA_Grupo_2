require "redis/namespace/version"

module Redis
  module Namespace
    # Your code goes here...
  end
end
