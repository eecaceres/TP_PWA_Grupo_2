module Redis
  module Namespace
    VERSION = "0.1.0"
  end
end
