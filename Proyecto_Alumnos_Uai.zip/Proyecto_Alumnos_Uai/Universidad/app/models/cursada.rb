class Cursada < ActiveRecord::Base
end
