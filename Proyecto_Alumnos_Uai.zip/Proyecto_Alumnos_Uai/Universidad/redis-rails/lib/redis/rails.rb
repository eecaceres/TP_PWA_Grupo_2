require "redis/rails/version"

module Redis
  module Rails
    # Your code goes here...
  end
end
