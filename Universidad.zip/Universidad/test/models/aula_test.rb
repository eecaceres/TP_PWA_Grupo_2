require 'test_helper'

class AulaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
