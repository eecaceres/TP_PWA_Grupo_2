$redis = Redis::Namespace.new("Universidad", :redis => Redis.new)
